ABAYNA TRAVAUX - SITE WEB GRATUIT
1. Ouvrir index.html pour tester le site.
2. Remplacer le téléphone +212 6 XX XX XX XX et le numéro WhatsApp 212600000000.
3. Remplacer l'email et la localisation.
4. Pour publier gratuitement: créer un compte GitHub, créer un dépôt nommé username.github.io, puis envoyer ces 3 fichiers (index.html, style.css, script.js). Activer GitHub Pages dans Settings > Pages.
